﻿using RimWorld;
using Verse;

namespace BuriedAlive
{
    [DefOf]
    public static class JobDefOf
    {
        public static JobDef BuryAlive;
    }
}
