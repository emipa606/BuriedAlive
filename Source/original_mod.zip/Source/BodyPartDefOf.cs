﻿using RimWorld;
using Verse;

namespace BuriedAlive
{
    [DefOf]
    public static class BodyPartDefOf
    {
        public static BodyPartDef Lung;
    }
}
